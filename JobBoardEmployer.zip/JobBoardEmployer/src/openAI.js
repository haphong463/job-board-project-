
const apiKey = 'sk-proj-lK0QgvafcrPBk1fUWYJyT3BlbkFJGUDdoY9IY3CmHZWHBnrG';
export default apiKey;
